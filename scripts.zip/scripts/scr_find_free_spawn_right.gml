/// scr_find_free_spawn_right()
/// Sposta l'istanza verso destra finché non trova una cella libera

var max_attempts = 100; // Numero massimo di tentativi
var attempts = 0;

while (ds_grid_get(global.cost_field, floor(x / global.grid_size), floor(y / global.grid_size)) >= 1000 && attempts < max_attempts) {
    // Sposta l'istanza di una cella verso destra
    x += global.grid_size;
    
    // Controlla se la nuova cella è valida
    if (ds_grid_get(global.cost_field, floor(x / global.grid_size), floor(y / global.grid_size)) < 1000) {
        break; // Esce dal loop appena trova una cella valida
    }
    
    attempts++;
}
